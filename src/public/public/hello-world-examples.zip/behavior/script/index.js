// print Hello world
console.log("Hello world")
