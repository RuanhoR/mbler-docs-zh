/**获取两个setA-setB */
export function difference(a: any, b: any): Set<any>;
/**对对象执行map方法 */
export function mapObject(obj: any, fn: any): {
    [k: string]: any;
};
