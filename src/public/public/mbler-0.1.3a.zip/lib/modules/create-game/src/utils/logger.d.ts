export const logLevel: any;
export class Logger {
    constructor(name: any);
    name: any;
    get logLevel(): import("./logger.js").logLevel;
    debug(message: any, ...optionalParams: any[]): void;
    log(message: any, ...optionalParams: any[]): void;
    warn(message: any, ...optionalParams: any[]): void;
    /**
     * 打印错误信息
     * @param message 消息
     * @param e 错误
     */
    error(message: any, e: any): void;
}
