export class EventManager {
    subscriptionMap: Map<any, any>;
    isActive: boolean;
    /**订阅事件 */
    subscribe(subscriber: any, event: any, ...args: any[]): EventSubscription | undefined;
    /**取消订阅 */
    unsubscribe(subscription: any): void;
    unsubscribeByEvent(event: any): void;
    /**取消订阅指定object的所有事件 */
    unsubscribeBySubscriber(subscriber: any): void;
    dispose(): void;
    debug(): void;
}
export class EventSubscription {
    constructor(event: any, subscriber: any, subscription: any);
    event: any;
    subscriber: any;
    subscription: any;
}
