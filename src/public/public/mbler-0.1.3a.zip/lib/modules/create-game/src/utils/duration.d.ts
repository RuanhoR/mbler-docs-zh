export class Duration {
    static ticksPerSecond: number;
    static ticksPerMinute: number;
    static fromSeconds(seconds: any): Duration;
    static fromMinutes(minutes: any): Duration;
    constructor(ticks: any);
    _ticks: any;
    /** 获取持续时间的刻数 */
    get ticks(): any;
    toSeconds(): number;
}
