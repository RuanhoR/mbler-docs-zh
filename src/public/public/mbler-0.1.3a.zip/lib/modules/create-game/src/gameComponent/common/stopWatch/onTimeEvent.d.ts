export class StopWatchOnTimeEventSignal {
    logger: Logger;
    events: any[];
    subscribe(callback: any, options: any): {
        unsubscribe: () => void;
    };
    /**检查并触发到达时间的事件*/
    checkAndFireTimeEvents(time: any): void;
}
import { Logger } from "../../../utils/logger.js";
