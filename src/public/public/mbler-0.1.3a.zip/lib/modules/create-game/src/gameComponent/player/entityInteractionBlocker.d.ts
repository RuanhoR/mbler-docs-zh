/**
 * 通用实体交互阻止组件
 */
export class EntityInteractionBlocker extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
}
import { GameComponent } from "../../main.js";
