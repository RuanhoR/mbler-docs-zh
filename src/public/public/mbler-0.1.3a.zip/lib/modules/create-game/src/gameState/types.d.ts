export class GameComponentNotExistsError extends GameStateError {
    constructor(componentType: any, tag: any, options: any);
}
export class GameComponentAlreadyExistsError extends GameStateError {
    constructor(componentType: any, tag: any, options: any);
}
export class ComponentLoadFailedError extends GameStateError {
    constructor(componentType: any, tag: any, options: any);
}
export class ComponentDeleteFailedError extends GameStateError {
    constructor(componentType: any, tag: any, options: any);
}
import { GameStateError } from "../utils/GameError.js";
