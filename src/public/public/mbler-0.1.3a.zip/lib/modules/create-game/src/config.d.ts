export class SAPIGameConfig {
    static _config: {};
    /** 获取当前配置（合并默认配置和用户配置） */
    static get config(): {
        logLevel: logLevel;
        onEnd: () => void;
        onJoin: () => void;
        hub: () => void;
        debugMode: boolean;
    };
    /** 更新配置（部分更新即可） */
    static update(config: any): void;
    /** 重置为默认配置 */
    static reset(): void;
}
import { logLevel } from "./utils/index.js";
