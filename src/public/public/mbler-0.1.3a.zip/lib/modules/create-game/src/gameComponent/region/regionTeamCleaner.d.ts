/**玩家离开指定区域时将他从team移除 */
export class RegionTeamCleaner extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
}
import { GameComponent } from "../gameComponent.js";
