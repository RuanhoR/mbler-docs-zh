export class StopWatchTickEventSignal {
    tickCallbacks: Set<any>;
    logger: Logger;
    /** 注册一个在每次时间增加（每秒）时执行的回调函数*/
    subscribe(callback: any): {
        unsubscribe: () => void;
    };
    publish(elapsedTime: any): void;
}
import { Logger } from "../../../utils/index.js";
