/**玩家组 */
export class PlayerGroup {
    constructor(playerClass: any, players: any, data: any);
    players: any;
    playerConstructor: any;
    data: any;
    /** 组中玩家数量(包含下线玩家) */
    get size(): any;
    /** 组中玩家数量(不包含下线玩家) */
    get validSize(): any;
    /** 根据 id 查找玩家 */
    getById(id: any): any;
    /** 是否包含玩家 */
    has(player: any): boolean;
    add(player: any): this;
    delete(player: any): this;
    removeWhere(func: any): any[];
    /**获取组中全部玩家的拷贝 */
    getAll(): any;
    /** 获取所有原生 Player 对象 */
    getAllPlayers(): any;
    /**对所有有效玩家执行操作 */
    forEach(func: any): void;
    /**组内所有玩家执行命令 */
    runCommand(commandString: any): this;
    /**向组内所有玩家发送消息 */
    sendMessage(mes: any): this;
    /**向组内所有玩家显示标题 */
    title(title: any, subtitle: any, options: any): this;
    actionbar(text: any): this;
    /**向组内所有玩家播放音效 */
    playSound(soundId: any, soundOptions: any): this;
    map(func: any): any;
    /**获取随机在线玩家 */
    random(): any;
    filter(func: any): any;
    /** 清空组 */
    clear(): this;
    /**清除无效玩家 */
    clearInvalid(): this;
    /** 克隆一份新的 PlayerGroup */
    clone(): PlayerGroup;
    /** 查找符合条件的玩家 */
    find(predicate: any): any;
    findIndex(predicate: any): any;
}
