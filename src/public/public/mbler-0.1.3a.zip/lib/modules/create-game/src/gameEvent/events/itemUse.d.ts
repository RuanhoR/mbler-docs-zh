export class ItemUseEventSignal extends BaseMapEventSignal<any, any, any, any, any> {
    constructor();
    buildKey(options: any): any;
    buildData(callback: any, options: any): {
        callback: any;
        itemId: any;
        players: any;
    };
    extractKey(event: any): any;
    filter(data: any, event: any): boolean;
    subscribeNative(cb: any): any;
    unsubscribeNative(cb: any): void;
}
import { BaseMapEventSignal } from "../mapEventSignal.js";
