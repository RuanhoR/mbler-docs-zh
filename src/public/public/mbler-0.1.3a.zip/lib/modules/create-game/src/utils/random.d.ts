export class RandomUtils {
    /** 返回 [0, max) 的随机整数 */
    static int(max: any): number;
    /** 返回 [min, max) 的随机整数 */
    static intRange(min: any, max: any): any;
    /** 从数组中随机取一个元素 */
    static choice(arr: any): any;
    /** 从数组中随机取多个不重复元素(洗牌算法) */
    static choices(arr: any, count: any): any[];
    /** 纯洗牌算法，返回一个新数组（Fisher–Yates Shuffle） */
    static shuffle(arr: any): any[];
    /** 就地洗牌（直接修改原数组） */
    static shuffleInPlace(arr: any): void;
    /** 随机布尔值（true/false） */
    static bool(): boolean;
    /** 按权重随机选择一个元素 */
    static weightedChoice(arr: any, weights: any): any;
    /**在圆形区域内随机选点 */
    static randomPointInCircle(x: any, y: any, rMax: any): any[];
}
