export class GameComponent {
    constructor(state: any, options: any, tag: any);
    options: any;
    _isAttached: boolean;
    /**是否已经attach */
    get isAttached(): boolean;
    state: any;
    /**tag */
    tag: any;
    get context(): any;
    get runner(): any;
    _onAttach(): void;
    _onDetach(): void;
    /**随便重写 */
    onDetach(): void;
    /**订阅事件 */
    subscribe(event: any, ...args: any[]): any;
    /**取消订阅 */
    unsubscribe(sub: any): void;
}
