export class PlayerHealthIndicator extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    obj: any;
    getObj(): any;
    /**展示 */
    show(): void;
    /**刷新计分板 */
    refresh(): void;
}
import { GameComponent } from "../index.js";
