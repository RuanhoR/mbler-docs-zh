/**区域队伍选择器 */
export class RegionTeamChooser extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    handleRegionEvent(event: any, data: any): void;
    handlePlayerEnter(gamePlayer: any, configData: any): void;
    handlePlayerLeave(gamePlayer: any, configData: any): void;
}
import { GameComponent } from "../gameComponent.js";
