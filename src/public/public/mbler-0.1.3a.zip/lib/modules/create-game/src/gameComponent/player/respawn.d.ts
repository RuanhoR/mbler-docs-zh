export class RespawnComponent extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    getKillerName(source: any): any;
}
import { GameComponent } from "../index.js";
