/**
 * BFS 遍历方块
 * @param startBlock 起始方块
 * @param condition 判断方块是否满足条件
 * @param maxDistance 可选，最大遍历距离
 */
export function bfsBlocks(startBlock: any, condition: any, maxDistance?: number, maxBlocks?: number): any[];
/** 线性插值 */
export function linspace(start: any, end: any, num: any): any[];
