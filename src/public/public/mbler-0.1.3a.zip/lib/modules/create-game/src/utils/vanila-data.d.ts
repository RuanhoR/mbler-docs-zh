/**维度 */
export const DimensionIds: any;
/** 相机视角/预设 */
export const CameraPreset: any;
export const EntityTypeIds: any;
/**各种状态效果 */
export const EffectIds: any;
/** 颜色与ID 对应表*/
export const colorIdMap: string[];
