export class globalPlayerManager {
    players: Map<any, any>;
    logger: Logger;
    /** 玩家是否已被分配（不修改状态） */
    isPlayerAllocated(playerId: any): boolean;
    /**请求分配玩家
     * 系统调用
     * @returns boolean 是否成功分配
     */
    allocatePlayerToGame(playerId: any, gameKey: any): boolean;
    /**将玩家从指定游戏释放
     * 系统调用
     */
    releaseAllPlayerFromGame(gameKey: any): void;
    /**将玩家从指定游戏释放 */
    releasePlayerFromGame(playerId: any, gameKey: any): void;
    /**强制释放玩家 */
    forceReleaseFromGame(playerId: any): void;
    /**获取所有在线且没有分配游戏的玩家 */
    getFreePlayers(): any[];
    tick(): void;
    status(): string;
}
import { Logger } from "../utils/index.js";
