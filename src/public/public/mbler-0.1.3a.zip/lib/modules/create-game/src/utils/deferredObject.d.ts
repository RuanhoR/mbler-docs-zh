export function createDeferredObject(): {
    setTarget(obj: any): void;
    proxy: {};
};
