/**
 * 通用方块交互阻止组件
 */
export class BlockInteractionBlocker extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
}
import { GameComponent } from "../../main.js";
