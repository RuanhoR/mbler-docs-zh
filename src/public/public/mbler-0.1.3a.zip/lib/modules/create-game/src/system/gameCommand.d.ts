export function regGameCommand(customCommandRegistry: any): void;
