/**玩家组构建器 */
export class PlayerGroupBuilder {
    constructor(manager: any);
    playerManager: any;
    /**创建空的玩家组 */
    emptyGroup(...rest: any[]): PlayerGroup<never, any>;
    /** 从原生 Player 创建 PlayerGroup 并映射到 playerManager */
    fromPlayers(players: any, ...rest: any[]): PlayerGroup<import("./gamePlayer.js").GamePlayer, any>;
    /** 从已有 PlayerGroup 创建 engine PlayerGroup */
    fromGroup(group: any, ...rest: any[]): PlayerGroup<import("./gamePlayer.js").GamePlayer, any>;
    /**从某个区域创建 */
    fromRegion(dim: any, region: any, ...rest: any[]): PlayerGroup<any, any>;
    /**从所有玩家创建 */
    fromAll(...rest: any[]): PlayerGroup<any, any>;
}
import { PlayerGroup } from "./playerGroup.js";
