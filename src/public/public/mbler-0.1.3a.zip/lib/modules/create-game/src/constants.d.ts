export const Dimensions: object;
export namespace Constants {
    export { dims as dimension };
}
declare const dims: object;
export {};
