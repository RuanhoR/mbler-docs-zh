export const RegionEventType: any;
export class PlayerRegionEventSignal {
    constructor(tickEvent: any);
    tickEvent: any;
    logger: Logger;
    subscription: null;
    allSubscriptions: Set<any>;
    regionStates: Map<any, any>;
    subscribe(callback: any, region: any): {
        unsubscribe: () => void;
    };
    startMonitoring(): void;
    stopMonitoring(): void;
    checkAllRegions(): void;
    publish(player: any, type: any, subscription: any): void;
    dispose(): void;
}
import { Logger } from "../../utils/logger.js";
