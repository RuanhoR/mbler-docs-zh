/**玩家组集合 */
export class PlayerGroupSet {
    constructor(groups: any);
    groups: any[];
    addGroup(group: any): this;
    removeGroup(group: any): this;
    getGroups(): any[];
    /**获取所有玩家，包括invalid的 */
    getAllPlayers(): any[];
    /**获取所有有效玩家 */
    getAllValidPlayers(): any[];
    /**对所有有效玩家执行操作*/
    forEach(func: any): this;
    forEachGroup(func: any): void;
    /**让所有玩家执行命令 */
    runCommand(command: any): this;
    runCommands(commands: any): void;
    /**向所有玩家发送消息 */
    sendMessage(mes: any): this;
    /**对所有玩家显示标题 */
    title(title: any, subtitle: any, options: any): this;
    filter(predicate: any): any[];
    clear(): this;
    clearInvalid(): void;
    clone(): PlayerGroupSet;
    get size(): number;
    get validSize(): number;
    /** 根据玩家 ID 查找玩家及其所在组 */
    findById(id: any): {
        player: any;
        group: any;
    } | undefined;
    /**判断玩家是否在内 */
    has(id: any): boolean;
}
