/**当玩家指定槽位出现指定物品时触发 */
export class PlayerItemInSlotEventSignal {
    constructor(intervalEvent: any);
    intervalEvent: any;
    tickSub: null;
    map: Map<any, any>;
    logger: Logger;
    subscribe(callback: any, options: any): {
        unsubscribe: () => void;
    };
    wrapUnsubscribe(data: any): {
        unsubscribe: () => void;
    };
    cleanUp(): void;
    tick(): void;
}
import { Logger } from "../../utils/index.js";
