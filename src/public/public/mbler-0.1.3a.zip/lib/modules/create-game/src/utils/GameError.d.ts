export class GameError extends Error {
    constructor(mes: any, options: any);
}
export class GameManagerError extends GameError {
}
export class GameEngineError extends GameError {
}
export class GameStateError extends GameError {
}
