/**自定义事件 */
export class BasicCustomEventSignal {
    set: Set<any>;
    logger: Logger;
    unsubscribe(item: any): void;
    publish(data: any): void;
}
import { Logger } from "../utils/logger.js";
