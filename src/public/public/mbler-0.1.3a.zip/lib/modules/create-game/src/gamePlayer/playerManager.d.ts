/**游戏玩家管理器 */
export class GamePlayerManager {
    constructor(playerConstructor: any, gameKey: any, isDaemon: any);
    gameKey: any;
    isDaemon: any;
    players: Map<any, any>;
    playerConstructor: any;
    /**玩家组构建器 */
    groupBuilder: any;
    /**获取游戏玩家(若玩家已分配，返回无效玩家) */
    get(p: any): any;
    getAll(): any[];
    /**让玩家失活 */
    deactivate(p: any): void;
    get size(): number;
    get validSize(): number;
    dispose(): void;
}
