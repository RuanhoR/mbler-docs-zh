/**游戏玩家基类 */
export class GamePlayer {
    constructor(player: any);
    _player: any;
    id: any;
    name: any;
    /**是否仍然在当前游戏（调用/hub等会为false） */
    isActive: boolean;
    get isValid(): any;
    /**获取player
     * 若玩家下线或失效返回undefined
     */
    get player(): any;
    /**发送消息 */
    sendMessage(mes: any): void;
    /**运行命令 */
    runCommand(cmd: any): any;
    /**给物品 */
    giveItem(item: any): void;
    /**清除(使用命令)*/
    clear(itemId: any): void;
    /**展示title */
    title(title: any, subtitle: any, options: any): void;
    /**设置actionbar文字 */
    actionbar(text: any): void;
    /**
     * 为玩家添加效果
     * @param showParticles 是否显示粒子，默认为false
     */
    addEffect(effectType: any, duration: any, amplifier: any, showParticles: any): void;
}
/**带寿命的player */
export class TTLPlayer extends GamePlayer {
    /**初始TTL，可override */
    initialTTL: number;
    _ttl: number;
    /**剩余寿命(自动处理isActive) */
    set ttl(value: number);
    /**获取玩家剩余存活时间 */
    get ttl(): number;
}
