export class TeamScoreBoard extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    obj: any;
    lastRefresh: number;
    getObj(): any;
    reset(): void;
    /**显示 */
    show(): void;
    /**刷新选队计分板 */
    refreshScoreBoard(): void;
}
import { GameComponent } from "../gameComponent.js";
