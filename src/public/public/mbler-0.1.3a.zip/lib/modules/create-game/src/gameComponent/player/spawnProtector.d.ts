export class SpawnPointProtector extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    /** 设置玩家重生点 */
    setPlayerSpawnPoints(): void;
    /** 传送所有玩家到出生点 */
    teleportAllToSpawn(): void;
    /** 循环保护出生点区域 */
    protectSpawnAreas(): void;
}
import { GameComponent } from "../gameComponent.js";
