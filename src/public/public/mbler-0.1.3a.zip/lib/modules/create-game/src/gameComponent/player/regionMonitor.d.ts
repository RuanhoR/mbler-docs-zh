/**玩家区域监测 */
export class PlayerRegionMonitor extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    detectOutOfRegionPlayers(): void;
}
import { GameComponent } from "../gameComponent.js";
