/**游戏订阅句柄*/
export class GameEventSubscription {
    constructor(event: any, callback: any);
    event: any;
    callback: any;
    /**取消订阅事件 */
    unsubscribe(): void;
}
