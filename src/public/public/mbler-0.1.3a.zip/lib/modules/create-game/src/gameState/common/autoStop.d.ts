/**自动在groupSet所有玩家寄了之后停止游戏 */
export class AutoStopState extends GameState<any, any, any, import("../../gameEngine.js").GameEngine<any, any, unknown>> {
    constructor(engine: import("../../gameEngine.js").GameEngine<any, any, unknown>, config?: any);
    tick(): void;
}
import { GameState } from "../../main.js";
