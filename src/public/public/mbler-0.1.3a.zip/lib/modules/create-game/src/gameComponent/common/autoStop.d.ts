/**在组中所有玩家寄了之后自动结束游戏 */
export class AutoStopComponent extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    tick(): void;
}
import { GameComponent } from "../../main.js";
