export class StopWatch extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    elapsedTime: number;
    _isRunning: boolean;
    lastTime: number;
    isActive: boolean;
    events: {
        tick: StopWatchTickEventSignal;
        onTime: StopWatchOnTimeEventSignal;
    };
    /** 获取当前已计时间（秒） */
    get time(): number;
    /** 获取秒表是否正在运行 */
    get isRunning(): boolean;
    /** 重置秒表时间 */
    reset(time?: number): void;
    /** 停止秒表 */
    stop(): void;
    /** 启动秒表 */
    start(): void;
    /** 暂停或恢复 */
    toggle(): void;
}
import { GameComponent } from "../../gameComponent.js";
import { StopWatchTickEventSignal } from "./tickEvent.js";
import { StopWatchOnTimeEventSignal } from "./onTimeEvent.js";
