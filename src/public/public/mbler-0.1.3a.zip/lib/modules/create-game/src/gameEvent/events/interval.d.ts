/** 间隔时间事件 */
export class IntervalEventSignal {
    intervalId: null;
    items: Set<any>;
    logger: Logger;
    subscribe(callback: any, interval: any): {
        unsubscribe: () => boolean;
    };
    start(): void;
    tick(): void;
    dispose(): void;
}
import { Logger } from "../../utils/index.js";
