/**用于懒加载区块 */
export class LazyLoader extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    active: boolean;
    logger: Logger;
    components: any[];
    get isActive(): boolean;
    clearComponents(): void;
    reload(): void;
    addComponent(component: any, options: any): this;
}
import { GameComponent } from "../gameComponent.js";
import { Logger } from "../../utils/index.js";
