export class ScriptCancelledError extends Error {
    constructor(id: any);
}
export class ScriptRunner {
    constructor(id: any, onFinish: any);
    id: any;
    onFinish: any;
    cancelled: boolean;
    checkCancelled(): void;
    wait(ticks: any): Promise<any>;
    do(fn: any): any;
    runSteps(steps: any): Promise<void>;
    doDelay(fn: any, ticks: any): Promise<any>;
    cancel(): void;
    run(script: any): Promise<void>;
    isCancelled(): boolean;
}
