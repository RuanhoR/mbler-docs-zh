export class SignClickEventSignal extends BaseMapEventSignal<any, any, any, any, any> {
    constructor();
    signId: string;
    buildKey(options: any): string;
    buildData(callback: any, options: any): {
        callback: any;
        players: any;
        lastClick: number;
        clickInterval: any;
    };
    extractKey(event: any): string;
    isTargetEvent(event: any): boolean;
    filter(data: any, event: any): boolean;
    subscribeNative(cb: any): any;
    unsubscribeNative(cb: any): void;
}
import { BaseMapEventSignal } from "../mapEventSignal.js";
