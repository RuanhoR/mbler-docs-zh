export class ButtonPushEventSignal extends BaseMapEventSignal<any, any, any, any, any> {
    constructor();
    buildKey(options: any): string;
    buildData(callback: any, options: any): {
        callback: any;
        players: any;
        sourceType: any;
    };
    extractKey(event: any): string;
    filter(data: any, event: any): boolean;
    subscribeNative(cb: any): any;
    unsubscribeNative(cb: any): void;
}
import { BaseMapEventSignal } from "../mapEventSignal.js";
