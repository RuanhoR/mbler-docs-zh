export class PlayerOnBlockEventSignal {
    static BELOW_OFFSET: {
        x: number;
        y: number;
        z: number;
    };
    constructor(tickEvent: any);
    tickEvent: any;
    blockMap: Map<any, any>;
    globalSubs: Set<any>;
    logger: Logger;
    subscription: null;
    subscribe(callback: any, options: any): {
        unsubscribe: () => void;
    };
    wrapUnsubscribe(remove: any): {
        unsubscribe: () => void;
    };
    cleanUp(): void;
    tick(): void;
}
import { Logger } from "../../utils/index.js";
