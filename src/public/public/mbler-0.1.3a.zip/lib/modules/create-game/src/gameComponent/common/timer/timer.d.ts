export class Timer extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    remainingTime: number;
    _isRunning: boolean;
    lastTime: number;
    events: {
        tick: TimerTickEventSignal;
        onTime: TimerOnTimeEventSignal;
    };
    /** 获取当前剩余时间 */
    get time(): number;
    /**获取计时器是否正在运行*/
    get isRunning(): boolean;
    /** 设置计时器的当前时间 */
    set(time: any): void;
    /**停止计时器 */
    stop(): void;
    /**启动计时器 */
    start(): void;
}
import { GameComponent } from "../../gameComponent.js";
import { TimerTickEventSignal } from "./tickEvent.js";
import { TimerOnTimeEventSignal } from "./onTimeEvent.js";
