/** 通用事件信号基类 */
export class BaseMapEventSignal {
    logger: Logger;
    map: Map<any, any>;
    totalCount: number;
    inited: boolean;
    nativeUnsub: any;
    subscribe(callback: any, options: any): {
        unsubscribe: () => void;
    };
    wrapUnsub(key: any, data: any): {
        unsubscribe: () => void;
    };
    init(): void;
    cleanup(): void;
    publish(event: any): void;
    /** 子类可重写：是否为需要的事件 */
    isTargetEvent(event: any): boolean;
    /**自定义事件返回 */
    eventWrapper(event: any): any;
}
import { Logger } from "../utils/index.js";
