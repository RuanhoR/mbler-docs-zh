/**信息侧边栏 */
export class InfoScoreboard extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    objective: any;
    initCode: number;
    getObj(): any;
    /**手动显示计分板 */
    show(): void;
    /**更新计分板内容 */
    updateLines(lines: any): void;
}
import { GameComponent } from "../gameComponent.js";
