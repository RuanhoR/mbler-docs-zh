export class RegionProtector extends GameComponent<any, any> {
    constructor(state: any, options?: any, tag?: string);
    handleBreak(t: any): void;
    handleInteract(t: any): void;
}
import { GameComponent } from "../gameComponent.js";
