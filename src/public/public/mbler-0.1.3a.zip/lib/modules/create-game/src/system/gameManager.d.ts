export class GameManager {
    games: Map<any, any>;
    logger: Logger;
    addGame(map: any, key: any, gameInstance: any): void;
    /**
     * 启动指定游戏
     * @throws GameManagerError 当游戏已存在时
     */
    startGame(game: any, config: any, tag: any): void;
    /**获取指定tag游戏是否已存在 */
    hasGame(game: any, tag: any): boolean;
    /**获取game */
    getGame(game: any, tag: any): any;
    getGameByKey(key: any): any;
    stopGame(game: any, tag: any): void;
    stopGameByKey(key: any): void;
    /**停止所有普通游戏 */
    stopAll(): void;
    /**静默停止所有普通游戏 */
    end(): void;
    status(player: any, detail: any): void;
    buildKey(game: any, tag: any): string;
}
import { Logger } from "../utils/logger.js";
