export const utils: {
    DataToplayer({ dimension, id, name, all }?: {}): import("@minecraft/server").Player | import("@minecraft/server").Player[] | undefined;
    DateToblock({ dimension, Location }?: {}): import("@minecraft/server").Block | undefined;
    playerToData(player: any): {
        id: any;
        all: boolean;
    };
    isEntityObject(player: any): boolean;
    dimensionList: string[];
    typeVerify(Object: any, ObjectSet: any): boolean;
    isObject(Obj: any): boolean;
    isIterator(obj: any): boolean;
    getEffect(name: any): string;
    in(num: any, min: any, max: any): boolean;
};
export { Vector3 };
