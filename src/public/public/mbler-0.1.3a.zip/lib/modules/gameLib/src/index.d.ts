export class GameLib {
    constructor(isLoger?: boolean);
    regLayout: (layout: any) => any[];
    loger: {
        d(msg: any): void;
        e(error: any): void;
        w(msg: any): void;
    };
    event: {
        runningSubscriptions: Map<any, any>;
        runningTimers: Map<any, any>;
        logger: any;
        entityWrapperMap: {
            entity: (logger: any, entity: any) => Entity;
        };
        _isInternalCall: boolean;
        _bindEvent(callback: any, timing: any, eventName: any, params?: any[], source?: string): {
            code: number;
            id: number;
            msg: any;
        };
        _generateId(): number;
        stop(id: any): {
            code: number;
            msg: any;
        };
        PlayerAdd(callback: any, timing?: string): {
            code: number;
            id: number;
            msg: any;
        };
        EntityDie(callback: any): {
            code: number;
            id: number;
            msg: any;
        };
        EntityHitE(callback: any): {
            code: number;
            id: number;
            msg: any;
        };
        EntityHitB(callback: any): {
            code: number;
            id: number;
            msg: any;
        };
        BreakB(callback: any, timing?: string): {
            code: number;
            id: number;
            msg: any;
        };
        EntityAdd(callback: any): {
            code: number;
            id: number;
            msg: any;
        };
        UseItem(callback: any, timing?: string): {
            code: number;
            id: number;
            msg: any;
        };
        WatchDogStop(callback: any): {
            code: number;
            id: number;
            msg: any;
        };
        setTimer(callback: any, tickDelay: any, isInterval?: boolean): {
            code: number;
            id: number;
            msg: any;
        };
    };
    entity: (rawEntity: any) => Entity;
    createForm: (name: any, opt: any) => import("./ui.js").UI;
}
import { Entity } from "./entity.js";
