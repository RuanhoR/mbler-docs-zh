export namespace loger {
    function d(msg: any): void;
    function e(error: any): void;
    function w(msg: any): void;
}
export namespace emtpyloger {
    function d(): void;
    function e(): void;
    function w(): void;
}
