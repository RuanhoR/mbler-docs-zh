export const event: {
    new (logger: any): {
        runningSubscriptions: Map<any, any>;
        runningTimers: Map<any, any>;
        logger: any;
        entityWrapperMap: {
            entity: (logger: any, entity: any) => EntityWrapper;
        };
        _isInternalCall: boolean;
        /**
         * 通用事件绑定方法（内部使用，请通过 PlayerAdd / EntityDie 等方法调用）
         */
        _bindEvent(callback: any, timing: any, eventName: any, params?: any[], source?: string): {
            code: number;
            id: number;
            msg: any;
        };
        _generateId(): number;
        /**
         * 停止指定 id 的事件订阅或定时任务
         */
        stop(id: any): {
            code: number;
            msg: any;
        };
        PlayerAdd(callback: any, timing?: string): {
            code: number;
            id: number;
            msg: any;
        };
        EntityDie(callback: any): {
            code: number;
            id: number;
            msg: any;
        };
        EntityHitE(callback: any): {
            code: number;
            id: number;
            msg: any;
        };
        EntityHitB(callback: any): {
            code: number;
            id: number;
            msg: any;
        };
        BreakB(callback: any, timing?: string): {
            code: number;
            id: number;
            msg: any;
        };
        EntityAdd(callback: any): {
            code: number;
            id: number;
            msg: any;
        };
        UseItem(callback: any, timing?: string): {
            code: number;
            id: number;
            msg: any;
        };
        WatchDogStop(callback: any): {
            code: number;
            id: number;
            msg: any;
        };
        setTimer(callback: any, tickDelay: any, isInterval?: boolean): {
            code: number;
            id: number;
            msg: any;
        };
    };
};
import { Entity as EntityWrapper } from "./entity.js";
