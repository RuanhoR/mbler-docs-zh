export class Vector3 {
    constructor(x1: any, y1: any, z1: any, dimension: any);
}
