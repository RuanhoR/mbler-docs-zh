/**
 * 拉取 Git 仓库
 * @param {string} repoDir - 本地 Git 仓库目录（如 './my-project'）
 * @returns {Promise<void>}
 */
export default function gitPull(repoDir: string): Promise<boolean>;
