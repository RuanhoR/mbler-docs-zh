import clone from "./clone.js";
import pull from "./pull.js";
export default class GitRepo {
    static clone: typeof clone;
    static pull: typeof pull;
}
