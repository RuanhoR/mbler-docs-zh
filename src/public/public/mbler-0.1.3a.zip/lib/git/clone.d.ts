/**
 * 克隆 Git 仓库
 * @param {string} repoUrl - Git 仓库地址
 * @param {string} targetDir - 本地目标目录（如 './my-project'）
 * @returns {Promise<void>}
 */
export default function gitClone(repoUrl: string, targetDir: string): Promise<unknown>;
