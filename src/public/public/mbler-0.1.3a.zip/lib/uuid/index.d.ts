import crypto from 'node:crypto';
export declare const fromString: (input: string, salt?: string) => string;
declare const _default: {
    fromString: (input: string, salt?: string) => string;
    uuid: typeof crypto.randomUUID;
};
export default _default;
