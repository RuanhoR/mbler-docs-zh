import util from 'util';
declare class Logger {
    #private;
    [util.inspect.custom]: () => string;
    getConsole(type: string, t: string): void;
    /**
     * 错误日志
     * @param {string} tag - 日志标签
     * @param {...*} msgs - 日志内容
     */
    e(tag: string, ...msgs: any[]): void;
    /**
     * 警告日志
     * @param {string} tag - 日志标签
     * @param {...*} msgs - 日志内容
     */
    w(tag: string, ...msgs: any[]): void;
    /**
     * 信息日志
     * @param {string} tag - 日志标签
     * @param {...*} msgs - 日志内容
     */
    i(tag: string, ...msgs: any[]): void;
    /**
     * 调试日志
     * @param {string} tag - 日志标签
     * @param {...*} msgs - 日志内容
     */
    d(tag: string, ...msgs: any[]): void;
    /**
     * @returns {string}
     */
    toString(): string;
}
declare const _default: Logger;
export default _default;
