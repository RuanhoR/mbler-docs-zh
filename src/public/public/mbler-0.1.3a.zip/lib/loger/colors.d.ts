declare const reset = "\u001B[0m";
declare const red = "\u001B[31m";
declare const yellow = "\u001B[33m";
declare const cyan = "\u001B[36m";
declare const white = "\u001B[37m";
export { reset, red, yellow, cyan, white };
