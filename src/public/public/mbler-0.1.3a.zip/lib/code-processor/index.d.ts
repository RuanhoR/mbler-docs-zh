interface ProcessOptions {
    modules?: string[];
    sourceDir: string;
    baseDir: string;
    minify?: boolean;
}
export default function processor(targetDir: string, options: ProcessOptions): Promise<void>;
export {};
