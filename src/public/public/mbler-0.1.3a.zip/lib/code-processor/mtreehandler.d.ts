export default class ImportManager {
    private code;
    private ast;
    private imports;
    constructor(code: string | null);
    private _parse;
    private _collectImports;
    has(moduleName: string): boolean;
    get(): Array<{
        ModuleName: string;
        ImportItem: string[];
    }>;
    set({ ModuleName, ImportItem }: {
        ModuleName: string;
        ImportItem: string[];
    }): void;
    private _syncAST;
    generate(): string;
}
