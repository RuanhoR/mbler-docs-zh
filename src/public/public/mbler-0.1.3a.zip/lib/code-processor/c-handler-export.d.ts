import ImportManager from './mtreehandler';
export default function (text: string | null): ImportManager;
