import { addPack } from './../module-handler/index.js';
export = addPack;
