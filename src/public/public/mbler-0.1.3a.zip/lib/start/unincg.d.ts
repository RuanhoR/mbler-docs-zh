declare const _default: (packName: string, dirname_: string) => Promise<void>;
export = _default;
