declare class Init {
    dir: string;
    dirName: string;
    constructor(dir: string, name: string);
    start(): Promise<void>;
    getVersion(param: string): Promise<string>;
    input(param: string, t?: boolean): Promise<string>;
}
export = Init;
