declare class Clean {
    p: string;
    dirname: string;
    outdir: string[];
    constructor(p: string, baseDir: string);
    run: () => Promise<void>;
    start(): Promise<void>;
    getOutDir(dir: string | undefined): string;
}
export default Clean;
