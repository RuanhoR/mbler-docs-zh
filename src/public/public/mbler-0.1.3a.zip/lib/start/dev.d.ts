declare const _default: (workDir: string, baseDir: string) => Promise<void>;
export = _default;
