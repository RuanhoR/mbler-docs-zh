import { installModules } from './../module-handler/index.js';
export = installModules;
