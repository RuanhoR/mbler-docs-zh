declare const _default: (dirname: string, workDir: string) => Promise<void>;
export = _default;
