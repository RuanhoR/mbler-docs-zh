declare const _default: (workDir: string, _dirname: string, param?: string) => Promise<void>;
export = _default;
