import { getResConfig } from './../module-handler/index.js';
export = getResConfig;
