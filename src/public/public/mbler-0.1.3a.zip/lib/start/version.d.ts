declare class Version {
    dir: string;
    baseDir: string;
    two: string;
    constructor(dir: string, baseDir: string);
    start(): Promise<void>;
    write(p: string, c: any): Promise<void>;
}
export = Version;
