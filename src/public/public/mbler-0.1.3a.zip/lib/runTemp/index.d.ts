import FileMethod from './File.js';
declare class Temp extends FileMethod {
    #private;
    static type: string;
    dir: string;
    cacheDesc: string;
    private timdir;
    private tempId;
    constructor(tempDir: string);
    init(): Promise<void>;
    wait(): AsyncGenerator<{
        LNnum: number;
    } | boolean>;
    remove(): Promise<void>;
}
export default Temp;
