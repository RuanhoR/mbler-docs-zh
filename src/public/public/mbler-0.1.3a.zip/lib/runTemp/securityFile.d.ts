export default class SecurityFile {
    #private;
    constructor(dir: string);
    mkdir(DirName: string): Promise<boolean>;
    rm(File: string): Promise<boolean>;
    writeFile(File: string, content: string | Buffer): Promise<boolean>;
    readFile(File: string, opt?: any): Promise<any>;
    readdir(Dir: string): Promise<string[]>;
}
