export default class FileMethod {
    #private;
    dir: string;
    mkdir(DirName: string): Promise<boolean>;
    rm(File: string): Promise<boolean>;
    writeFile(File: string, content: string | Buffer): Promise<boolean>;
    readFile(File: string): Promise<NonSharedBuffer>;
    readdir(Dir: string): Promise<string[]>;
}
