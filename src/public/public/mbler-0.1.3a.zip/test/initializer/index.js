require("./test.js")
exports.main = function({
  work
}) {
  console.log(work)
}