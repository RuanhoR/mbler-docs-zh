import {
  world
} from "@minecraft/server"
console.log('console in ts minecraft') 

world.getPlayers().sendMessage('text')